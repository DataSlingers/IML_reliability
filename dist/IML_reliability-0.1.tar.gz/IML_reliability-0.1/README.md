# minipatch-learning


## Installation

IML_reliability 0.1 and later require Python 3.7 or Python 3.8. 

Clone this repo and run

    python setup.py install



**The dependencies of this package will be automatically installed into your environment.**


## API Documentations

The detailed API documentation for this package can be found at [https://DataSlingers.github.io/IML_reliability]
